このリソースパックは
FTB Interaction ver.2.12.1の
	Gregtech : gregtech-1.12.2-1.10.2.566
	Shadows of Greg : Shadows_of_Greg-1.12.2-2.14
	CEU : ceu-1.12.2-1.0.4.3
専用です。